#include <iostream>
#include <cmath>

using namespace std;

int seqSize;
int sequence[1000]; //ja setado no tamanho maximo para evitar ficar passando na pilha de chamada de funcao

void seq_swap(int i, int j){ //troca duas posicoes do array sequence
    int aux = sequence[i]; //realizar o swap das duas posicoes
    sequence[i] = sequence[j];
    sequence[j] = aux;
}

void quickSort(int start, int finish){ //ordena o array sequence (escolhido por eficiencia em conjuntos pequenos e no uso de memoria)
    int i = start, j = finish,
        pivot = sequence[(start + finish) / 2]; //declarar variaveis iniciais

    while(i <= j){
        while(sequence[i] < pivot) i++; //re posicionar ponteiro do inicio
        while(sequence[j] > pivot) j--; //re posicionar ponteiro do final

        if(i <= j){
            seq_swap(i, j);
            i++; j--; //re ajustar os valores dos indexes
        }
    }

    if(j > start) quickSort(start, j); //se j nao for o inicio do array sequence
    if(i < finish) quickSort(i, finish); //se i nao for o final do array sequence
}

int findMaxFibonaccico(int f0Pos, int f1Pos){

    int seqIndexesAux[seqSize];
    int seqIndexesPos = 2;

    seqIndexesAux[0] = f0Pos;
    seqIndexesAux[1] = f1Pos;

    int auxfN0 = f0Pos, auxfN1 = f1Pos;

    int i;
    for(i = f1Pos + 1; i < seqSize; i++){
        if(sequence[auxfN0] + sequence[auxfN1] == sequence[i]){ //verificar se o proximo numero corresponde a sequencia proposta
            auxfN0 = auxfN1; //caso corresponda, atualizar valores
            auxfN1 = i;
            seqIndexesAux[seqIndexesPos++] = i;
        }
    }

    //verificar sequencia com outros inicios
    int maxAux0 = 2, maxAux1 = 2;
    if(f1Pos + 1 < seqSize){
        maxAux0 = findMaxFibonaccico(f0Pos, f1Pos + 1); //verificar com inicios diferentes para um "mesmo f0"
        maxAux1 = findMaxFibonaccico(f0Pos + 1, f1Pos + 1); //"avancar f0"
    }

    return max(seqIndexesPos, max(maxAux0, maxAux1));
}

int main()
{
    cin >> seqSize;

    int i;
    for(i = 0; i < seqSize; i++) cin >> sequence[i]; //ler cada elemento da entrada

    quickSort(0, seqSize - 1); //ordenar array sequence de entrada
    for(i = 0; i < seqSize; i++) cout << sequence[i] << " ";

    cout << '\n' << findMaxFibonaccico(0, 1) << endl;




    //encontrar maior sequencia fibonaccica
   /* int seqIndexesAux[seqSize];
    int seqIndexesPos = 0;

    for(i = 0; i < seqSize - 1; i++){
        seqIndexesPos = 0;
        seqIndexesAux[seqIndexesPos++] = i; //ajustar qual pos/index esta sendo utilizado para "re ordenar" o array (f0)

        for(j = i + 1; j < seqSize - 1; j++){
            seqIndexesAux[seqIndexesPos++] = j; //ajustar qual pos/index esta sendo utilizado para "re ordenar" o array (f1)

            for(k = 1; seqIndexesAux[seqIndexesPos - 1] + k < seqSize; k++){
                if(sequence[seqIndexesAux[seqIndexesPos - 2]]
                   + sequence[seqIndexesAux[seqIndexesPos - 1]] == sequence[seqIndexesAux[seqIndexesPos - 1] + k]){
                       seqIndexesAux[seqIndexesPos++] = j;
                }
            }
        }
    }*/


    //Exemplo de execucao:
    //Exemplo de execucao:

    return 0;
}
